<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'j~4u|VAF9)Ot1hf/LhAHG[=a!WoT dhNwLcU)m3 xrPDd87XGUTpR17c#8]LrQmG' );

define( 'SECURE_AUTH_KEY',  '~aHGkuyVCz!Uprz>d`=lz7^C9&2WV1|qN]CL:?FC(Ly,@1*gM;ZTPkhG;T%zZ9nP' );

define( 'LOGGED_IN_KEY',    '9TyZW,d3)9(&6kItG&$tMVJ-,dT4t+hDa4(tvZT4F7+^>,d^>z:W0}1x/6|4$4v(' );

define( 'NONCE_KEY',        '~ERpGb7a@PWnDL+6JtJ}4(~Dq)AxJ:%:9q[};71go6<+&<j(9X&.kqVSC(y4p$V4' );

define( 'AUTH_SALT',        '/;upuX3JI%]]_IIT7V5s>xnQS7<61zn;$ DU[NJz6wta^S(W{ZsO,haaC^n4B_SA' );

define( 'SECURE_AUTH_SALT', '3-B/k$U-=%_qkljxv+>4K{u|0ccu [02Q]ntS5j ~rG=.[WH;dFgo5X&.i1{Rf[G' );

define( 'LOGGED_IN_SALT',   '2Uw?n6]cYLP-r>>=@L@ XoA.{Y&um7oM[B514zL;BcYWkV2b18>_Cu,)oOJAGaCU' );

define( 'NONCE_SALT',       'oi25Nk;Zo-%LdndH;TL4)H*D|6  EoJ*[1#:h!}GJv*c~)F8PmMZVT7r;9$hfVtu' );




define('WP_REDIS_HOST', 'wp-redis.vdabii.ng.0001.use1.cache.amazonaws.com');

define('WP_CACHE', true);

/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

